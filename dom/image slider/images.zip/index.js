let Images = document.querySelector('img');
let photos = ['images/nazmul.jpg', 'images/5.jpg', 'images/4.jpg', 'images/6.jpg'];
let count = 0;

function next() {
    count++;
    if (count == photos.length) {
        count = 0;
    }
    Images.src = photos[count];
}

function prev() {
    count--;
    if (count < 0) {
        count = photos.length - 1;
    }
    Images.src = photos[count];
}

// Auto-slide feature
setInterval(next, 2000); // Change the image every 3 seconds
